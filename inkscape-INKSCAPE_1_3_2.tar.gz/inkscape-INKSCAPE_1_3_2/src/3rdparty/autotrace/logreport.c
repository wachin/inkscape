/* logreport.c: showing information to the user. */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* Def: HAVE_CONFIG_H */

#include "logreport.h"

gboolean logging = FALSE;
