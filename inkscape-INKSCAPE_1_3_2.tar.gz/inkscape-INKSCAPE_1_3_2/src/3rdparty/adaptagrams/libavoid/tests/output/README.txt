This directory is used to for output debug svg files from the testcases.
