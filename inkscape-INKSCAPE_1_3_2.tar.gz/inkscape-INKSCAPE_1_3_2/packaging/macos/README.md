# macOS build pipeline

The macOS build pipeline is developed separately from Inkscape's codebase and can be found here:  
[https://gitlab.com/inkscape/devel/mibap](https://gitlab.com/inkscape/devel/mibap)
