Packaging
=========

This directory contains files and utilities for creating source and
binary packages of Inkscape. Items in this directory typically are not
referenced, used, or included in the regular Inkscape builds.
